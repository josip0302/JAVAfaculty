package ui;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class Stablo {
    private class Node {
        Map<String,Node> map=new LinkedHashMap<>();
        String name;

    }


}
