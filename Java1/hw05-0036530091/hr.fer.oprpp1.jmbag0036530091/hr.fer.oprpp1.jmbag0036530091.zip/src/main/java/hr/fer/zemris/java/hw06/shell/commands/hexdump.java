package hr.fer.zemris.java.hw06.shell.commands;

import hr.fer.zemris.java.hw06.shell.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class hexdump implements ShellCommand {
    @Override
    public ShellStatus executeCommand(Environment env, String arguments) {
        try {
            File file = new File(arguments);
            if(file.isDirectory()){
                env.writeln("please give us name of the file not directory");
                return ShellStatus.CONTINUE;
            }
            FileInputStream stream=new FileInputStream(arguments.trim());
            byte[] poljeb = new byte[2048];
            int i = stream.read(poljeb);
            while (i > 0) {
                for (int b=0;b<i;b++){

                    int a=poljeb[b];
                    if(127>=a && a>=32) {
                        env.write(String.format("%02X",poljeb[b])+" ");
                    }else {
                        env.write(".");
                    }

                }env.writeln("");
                i = stream.read(poljeb);;
            }
            stream.close();
        } catch (Exception e) {
            System.out.println(e.getMessage()+"in class hexdump executeCommand method");
        }
        return ShellStatus.CONTINUE;
    }

    @Override
    public String getCommandName() {
        return "hexdump";
    }

    @Override
    public List<String> getCommandDescription() {
        List<String> rez=new ArrayList<>();
        rez.add("hexdump command expects a single argument: file name, and produces hex-outpu");
        return rez;
    }
}
