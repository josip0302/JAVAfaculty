package hr.fer.zemris.java.hw06.shell.commands;

public enum ShellStatus {
    CONTINUE, TERMINATE
}
