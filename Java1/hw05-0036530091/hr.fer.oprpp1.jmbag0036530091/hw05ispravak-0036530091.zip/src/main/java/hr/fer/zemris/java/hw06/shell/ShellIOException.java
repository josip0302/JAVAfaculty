package hr.fer.zemris.java.hw06.shell;

public class ShellIOException extends Exception {

}
