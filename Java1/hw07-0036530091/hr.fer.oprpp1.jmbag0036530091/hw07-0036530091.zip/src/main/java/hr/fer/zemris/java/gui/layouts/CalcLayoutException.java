package hr.fer.zemris.java.gui.layouts;

public class CalcLayoutException extends RuntimeException{
}
