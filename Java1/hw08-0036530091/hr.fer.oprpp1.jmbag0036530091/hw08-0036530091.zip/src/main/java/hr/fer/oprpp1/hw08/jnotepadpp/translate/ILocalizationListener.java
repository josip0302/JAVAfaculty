package hr.fer.oprpp1.hw08.jnotepadpp.translate;

public interface ILocalizationListener {
    void localizationChanged();
}
