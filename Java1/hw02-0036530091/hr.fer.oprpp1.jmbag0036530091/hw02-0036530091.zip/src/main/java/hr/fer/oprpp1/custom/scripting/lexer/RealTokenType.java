package hr.fer.oprpp1.custom.scripting.lexer;

public enum RealTokenType {
    VARIABLE,OPERATOR,FUNCTION,STRING,TEXT,TAGNAME,EOF,NUMBER;
}
