package hr.fer.oprpp1.custom.scripting.elems;

public class Element {
    /**
     *
     * @return element as text
     */
    public String asText(){
        return "";
    }
}
