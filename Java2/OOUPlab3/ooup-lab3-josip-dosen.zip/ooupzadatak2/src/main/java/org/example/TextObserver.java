package org.example;

public interface TextObserver {
    void updateText();
}
