package org.example;



public interface CursorObserver {
    void updateCursorLocation(Location loc);
}
