#ifndef _myfile_h
#define _myfactory_h

void* myfactory(char const* libname, char const* ctorarg, char const* alloc);

#endif