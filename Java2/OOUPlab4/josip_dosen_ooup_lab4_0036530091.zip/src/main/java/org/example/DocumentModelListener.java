package org.example;

public interface DocumentModelListener {
    void documentChange();
}
