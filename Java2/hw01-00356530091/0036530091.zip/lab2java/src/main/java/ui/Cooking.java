package ui;

public class Cooking {
    public Cooking(String arg, String arg1) {
        String fileName=arg;
        Resolution resolution=new Resolution(arg,Input.getInput(arg1));
    }
}
